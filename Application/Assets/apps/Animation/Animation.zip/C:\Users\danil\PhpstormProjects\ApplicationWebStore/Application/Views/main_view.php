<!doctype html>

<html lang="en">
<head>
    <?php include 'shared/header.html';?>
</head>

<body>

<div class="body">

    <svg class="banner mt-5 mb-5">
        <text x="40" y="40" fill="red"  ">I love SVG!</text>
    </svg>


</div>


</body>

<footer>
    <?php include 'shared/footer.html';?>
</footer>
</html>

