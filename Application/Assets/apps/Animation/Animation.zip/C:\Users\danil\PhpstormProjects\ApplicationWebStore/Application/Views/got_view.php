<!doctype html>

<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" class="" href="../Assets/images/favicon.ico">


    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap"
          rel="stylesheet">

    <title>Thank you for using our products!</title>

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="../Assets/css_phpjabbers/fontawesome.css">
    <link rel="stylesheet" href="../Assets/css_phpjabbers/style.css">
    <link rel="stylesheet" href="../Assets/css_phpjabbers/owl.css">

    <!-- Additional Scripts -->
    <script src="../Assets/js_phpjabbers/custom.js"></script>
    <script src="../Assets/js_phpjabbers/owl.js"></script>


    <?php
    include 'shared/header.html';
    include '../../DAL/dbconnection.php';

    if (isset($_GET['app']))
        $app_name = $_GET['app'];
    else $app_name = 'Paint';

    $app_name = "'$app_name'";


    global $db;

    $query = pg_query($db, "SELECT * FROM app WHERE name =" . $app_name);
    $app = pg_fetch_array($query);

    ?>
</head>

<body>
<div class="body">

    <h5 class="text-center">Thank you! Download will start soon...</h5>

    <?php

    function createZip($zip, $dir)
    {
        if (is_dir($dir)) {

            if ($dh = opendir($dir)) {
                while (($file = readdir($dh)) !== false) {

                    // If file
                    if (is_file($dir . $file)) {
                        if ($file != '' && $file != '.' && $file != '..') {

                            $zip->addFile($dir . $file);
                        }
                    } else {
                        // If directory
                        if (is_dir($dir . $file)) {

                            if ($file != '' && $file != '.' && $file != '..') {

                                // Add empty directory
                                $zip->addEmptyDir($dir . $file);

                                $folder = $dir . $file . '/';

                                // Read data of the folder
                                createZip($zip, $folder);
                            }
                        }

                    }

                }
                closedir($dh);
            }
        }
    }

    $zip = new ZipArchive();
    $filename = '../../../' . $app['link'] . '/' . $app['name'] . '.zip';

    if ($zip->open($filename, ZipArchive::CREATE) !== TRUE)
        exit("cannot open <$filename>\n");

    $dir = 'C:\Users\danil\PhpstormProjects\ApplicationWebStore/';
    createZip($zip, $dir);

    $zip->close();

    $filename = $dir.$app['name'].'.zip';



    if (file_exists($filename)) {
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        header('Content-Length: ' . filesize($filename));

        flush();
        readfile($filename);
    }
        else
        {
            echo "<script>alert('file is not exist')</script>";
            echo "<script>alert('$filename')</script>";
            echo $filename;
        }
    ?>

</div>
</body>

<footer>
    <?php include 'shared/footer.html'; ?>
</footer>
</html>






