<!DOCTYPE html>
<html lang="en">

<head>

    <?php
    require_once '../../DAL/dbconnection.php';

    if (isset($_GET['app']))
        $app_name = $_GET['app'];
    else $app_name = 'Paint';

    $app_name = "'$app_name'";


    global $db;

    $query = pg_query($db, "SELECT * FROM app WHERE name =" . $app_name);
    $app = pg_fetch_array($query);
    ?>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" class="" href="../Assets/images/favicon.ico">


        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap"
              rel="stylesheet">

        <title><?php echo $app['name'] ?></title>

        <!-- Additional CSS Files -->
        <link rel="stylesheet" href="../Assets/css_phpjabbers/fontawesome.css">
        <link rel="stylesheet" href="../Assets/css_phpjabbers/style.css">
        <link rel="stylesheet" href="../Assets/css_phpjabbers/owl.css">

        <!-- Additional Scripts -->
        <script src="../Assets/js_phpjabbers/custom.js"></script>
        <script src="../Assets/js_phpjabbers/owl.js"></script>

        <?php include 'shared/header.html'; ?>
    </head>

<body>

<!-- Page Content -->


<div class="body">
    <div class="products">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-4 col-xs-12">
                    <?php echo '
                <div>
                    <img src="../../../' . $app['cover'] . '" alt="" class="img-fluid wc-image" height="300px">
                </div>
                <br>
                <div class="row">
                    <div class="col-sm-4 col-xs-6">
                        <div>
                            <img src="../../../' . $app['cover'] . '" alt="" class="img-fluid" height="100px">
                        </div>
                        <br>
                    </div>
                    <div class="col-sm-4 col-xs-6">
                        <div>
                            <img src="../../../' . $app['cover'] . '" alt="" class="img-fluid" height="100px">
                        </div>
                        <br>
                    </div>
                    <div class="col-sm-4 col-xs-6">
                        <div>
                            <img src="../../../' . $app['cover'] . '" alt="" class="img-fluid" height="100px">
                        </div>
                        <br>
                    </div>
                </div>
            </div>

            <div class="col-md-8 col-xs-12">
                <form action="#" method="post" class="form">
                    <h2>' . $app['name'] . '</h2>

                    <br>

                    <p class="lead">
                        <small><del> $999.00</del></small><strong> FREE</strong>
                    </p>

                    <br>

                    <p class="lead">
                        ' . $app['description'] . '
                    </p>

                    <br>
                                <div class="col-sm-6">
                                    <a href="http://localhost:63342/ApplicationWebStore/Application/Views/got_view.php?app='.$app['name'].'" class="btn btn-primary btn-block pink-button">Get</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
'; ?>
                    <div class="latest-products">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="section-heading">
                                        <h2>Similar Products</h2>
                                        <a href="products.html">view more <i class="fa fa-angle-right"></i></a>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="product-item">
                                        <a href="product-details.html"><img src="assets/images/product-1-370x270.jpg"
                                                                            alt=""></a>
                                        <div class="down-content">
                                            <a href="product-details.html"><h4>Omega bicycle</h4></a>
                                            <h6><small>
                                                    <del>$999.00</del>
                                                </small> $779.00
                                            </h6>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="product-item">
                                        <a href="product-details.html"><img src="assets/images/product-2-370x270.jpg"
                                                                            alt=""></a>
                                        <div class="down-content">
                                            <a href="product-details.html"><h4>Nike Revolution 5 Shoes</h4></a>
                                            <h6><small>
                                                    <del>$99.00</del>
                                                </small> $79.00
                                            </h6>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="product-item">
                                        <a href="product-details.html"><img src="assets/images/product-3-370x270.jpg"
                                                                            alt=""></a>
                                        <div class="down-content">
                                            <a href="product-details.html"><h4>Treadmill Orion Sprint</h4></a>
                                            <h6><small>
                                                    <del>$1999.00</del>
                                                </small> $1779.00
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</body>

<footer><?php include 'shared/footer.html'; ?>'</footer>
</html>


<?php

function Download($app)
{


    $filename = $app['link'] . '/' . $app['name'] . '.zip';

    if (file_exists($filename)) {
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        header('Content-Length: ' . filesize($filename));

        flush();
        readfile($filename);
        // delete file
        unlink($filename);

    } else echo "<script>alert('file is not exist')</script>";
}

?>




