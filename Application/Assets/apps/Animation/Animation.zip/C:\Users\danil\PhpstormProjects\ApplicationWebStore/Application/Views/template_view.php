<!DOCTYPE html>
<html lang="ru">
<head>
    <link rel="stylesheet" type="text/css" href="/Application/Assets/css/style.css" />
    <script src="/js/jquery-1.6.2.js" type="text/javascript"></script>

    <meta charset="utf-8">
    <title>Главная</title>
</head>
<body>
<?php include 'application/views/'.$content_view; ?>
</body>
</html>