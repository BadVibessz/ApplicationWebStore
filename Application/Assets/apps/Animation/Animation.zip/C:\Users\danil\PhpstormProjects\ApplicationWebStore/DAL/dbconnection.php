<?php

$db = pg_connect("host=localhost port=5432 dbname=AppStore user=postgres password=gunna");

